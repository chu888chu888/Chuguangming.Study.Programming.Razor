using System.Windows.Controls;

namespace RazorPad.UI
{
    public abstract class ModelBuilder : UserControl, IModelBuilder
    {
    }
}