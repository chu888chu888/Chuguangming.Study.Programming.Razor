namespace RazorPad.UI.Editors
{
    internal interface ICodeEditorStrategy
    {
        void Apply(CodeEditor editor);
    }
}