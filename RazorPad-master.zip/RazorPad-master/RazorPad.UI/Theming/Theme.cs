namespace RazorPad.UI.Theming
{
    public class Theme
    {
        public string Name { get; set; }
        public string FilePath { get; set; }
        public bool Selected { get; set; }
    }
}