namespace RazorPad.UI
{
    public interface IModelBuilder
    {
    }
}