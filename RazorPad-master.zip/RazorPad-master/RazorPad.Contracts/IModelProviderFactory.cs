namespace RazorPad
{
    public interface IModelProviderFactory
    {
        IModelProvider Create();
    }
}