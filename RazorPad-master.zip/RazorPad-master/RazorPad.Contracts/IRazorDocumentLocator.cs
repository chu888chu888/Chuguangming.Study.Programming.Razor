namespace RazorPad.Persistence
{
    public interface IRazorDocumentLocator
    {
        string Locate();
    }
}