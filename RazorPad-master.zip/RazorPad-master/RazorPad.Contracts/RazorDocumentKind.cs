namespace RazorPad
{
    public enum RazorDocumentKind
    {
        TemplateOnly,
        Full,
    }
}