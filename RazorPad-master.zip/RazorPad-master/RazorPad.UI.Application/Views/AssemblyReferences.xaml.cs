﻿namespace RazorPad.Views
{
	public partial class AssemblyReferences
	{
        public AssemblyReferences()
        {
            InitializeComponent();
        }
    }
}
