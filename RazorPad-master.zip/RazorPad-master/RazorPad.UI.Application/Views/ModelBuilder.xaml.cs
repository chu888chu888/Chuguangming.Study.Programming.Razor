﻿using System.Windows.Controls;

namespace RazorPad.Views
{
    /// <summary>
    /// Interaction logic for Sidebar.xaml
    /// </summary>
    public partial class ModelBuilder : UserControl
    {
        public ModelBuilder()
        {
            InitializeComponent();
        }
    }
}
