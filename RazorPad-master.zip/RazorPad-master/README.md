RazorPad is a quick and simple stand-alone editing environment that allows anyone (even non-developers) to author Razor templates. It is the Notepad 
for Razor.

The application is developed in WPF using C# and relies on the System.WebPages.Razor libraries (included in the project download).
