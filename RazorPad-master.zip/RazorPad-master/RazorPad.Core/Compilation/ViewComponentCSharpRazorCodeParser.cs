﻿using System.Web.Mvc.Razor;

namespace RazorPad.Compilation
{
    public class RazorPadCSharpRazorCodeParser : MvcCSharpRazorCodeParser
    {
    }
}